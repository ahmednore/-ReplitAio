# Replit Aio
Replit Aio with Account Generator and more!


![Screenshot](aio.png)


# ・How to use
・Put proxies in proxies.txt: https://www.webshare.io/?referral_code=27rjvonmaef4

・Capmonster key in config: https://capmonster.cloud/Dashboard

# ・About

・Leave all Suggestions in a pull request or issue

・It takes 2 seconds to star, longer to maintain :)

## Generator Features
```
・Account Generator

・Email Verify

・Profile Picture Changer

・Bio Changer

・Onliner

・Creates Repl On signup

```

## Aio Features

```
・Follow bot

・Unfollow bot

・Fork bot

・Run bot

・Report bot

・Username Checker

・Pfp Changer

・Banner Changer

・Bio Changer
```


 ## 🥅 ・Goals
```
・ 5 stars I will add follow bot ✅

・ 10 stars I will add a fork bot ✅

・ 15 stars I will add a run bot ✅

・ 20 Stars I will add a like bot ✅

・ Turns out hcaptcha is gae and patched bypass :(
```

## Want help?
・Join my discord
https://discord.gg/phts


## ・Skids
```
supreme#1049 - Selling for nitro
```


## 📄・License

This project is licensed under the GPL General Public License v3.0 License - see the [LICENSE.md](./LICENSE) file for details
```js
  ・Educational purpose only and all your consequences caused by you actions is your responsibility
  ・Selling this Free gen is forbidden
  ・If you make a copy of this/or fork it, it must be open-source and have credits linking to this repo
```

## 📄・Important
```
・This is for Educational purpose only all your consequences caused by your actions is your responsibility 
・Selling this Free gen is forbidden 
・If you make a copy of this/or fork it, it must be open-source and have credits linking to this repo, this is simply showing how the site can be overruled.
```

## 💭・ChangeLog

```diff
v1 ⋮ 14/8/22
+ Stable Release

v1.2 ⋮ 16/8/22
+ Fork Bot
+ Follow Bot

v2 ⋮ 16/8/22
+ Aio
```


## Custom work
```
For custom work contact !Hazza#0001
```






